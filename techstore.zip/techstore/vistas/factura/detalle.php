<h1>Detalle de Factura</h1>
<p>ID: <?php echo $factura->id; ?></p>
<p>Fecha: <?php echo $factura->fecha; ?></p>
<p>Total: <?php echo $factura->total; ?></p>
<p>Método de Pago: <?php echo $factura->metodo_pago; ?></p>