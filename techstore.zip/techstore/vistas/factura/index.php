<h1>Inicio de Facturas</h1>
<a href="?c=factura&a=crear">Crear Nueva Factura</a>
<a href="?c=factura&a=mostrar">Ver Facturas</a>
