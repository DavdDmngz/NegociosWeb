<!-- Carousel Start -->
    <div class="container-fluid mb-3">
        <div class="row px-xl-5">
            <h3>Cantidad de usuarios</h3>
            <?php $p=$this->modelo->Cantidad();
            echo "<h3> =" . $p->CANTIDAD . "</h3>";?>
        </div>
    </div>
<!-- Carousel End -->